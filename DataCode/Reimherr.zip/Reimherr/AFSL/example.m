% This is a simulation to illustrate high-dimensional adaptive function-on-scalar regression in Fan and Reimherr(2016).
% This code was initially written by Rina Foygel Barber, and then expanded and edited by Zhaohu(Jonathan) Fan.


% set a path for implementing the algorithms
%addpath(genpath('X:/16_ResearchOneFile/ADMM/testing_2_24'));
addpath(genpath('/Users/Matthew/Desktop/ForJeff/AFSL'));

%% Data Sets Generation
% processing the data sets.

I =500;  % the number of covariates
N =100;   % the number of observations

% First we set parameters for simulations
nlam_base=100;
BIC_para = 1;
FEV_thresh = 0.95;
M0 = 50; 
M=M0;
I0 = 10;  % we arbitrarily select 10 covariates out of I as our target covariables;
rho = 0.5;
nbasis = min([50 M0]);
T_domain = (0:(M0-1))/(M0-1); 

% Next we set up the covariates parameters for Matern process%

mu_X = zeros(I,1); 
Sig_X = ones(I,I); 
for i = 1:(I-1)
    for j = (i+1):I
        Sig_X(i,j) = rho^(j-i);
        Sig_X(j,i) = Sig_X(i,j);
    end
end 
% Here we set  signals parameters for our model %
nu_alpha = 2.5; 
range = 1/4;
variance = 1;
hyp = [log(range),log(variance)/2]; 
% we set errors parameters for our model%
nu_eps = 1.5;
mu_eps = zeros(M0,1);
range1=0.01; 
variance = 1;
hyp1 = [log(range1),log(variance)/2]; 
Sig_eps=covMaterniso(2*nu_eps,hyp1,T_domain');
Sig_eps2 = (Sig_eps + Sig_eps.')./2;
mu_alpha = zeros(M0,1);
Sig_alpha = covMaterniso(2*nu_alpha,hyp,T_domain');

X = mvnrnd(mu_X,Sig_X,N);
X= zscore(X);
alpha_1 = mvnrnd(mu_alpha,Sig_alpha,I0); 
eps = mvnrnd(mu_eps,Sig_eps2,N);
I_X = randsample(I,I0,false); 
Y_full = X(:,I_X)*alpha_1+ eps;



subplot(1,3,1)
plot(T_domain,Y_full')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'Y(t) functions'},'FontSize',8,'FontWeight','bold')

subplot(1,3,2)
plot(T_domain,eps')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'error coefficients'},'FontSize',8,'FontWeight','bold')
subplot(1,3,3)
plot(T_domain,alpha_1')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'betas functions'},'FontSize',8,'FontWeight','bold')


% Call on FSL and AFSL
M_pc=3;

[history]=AFSL(N, M, I, M_pc,Y_full,X);

subplot(1,3,1)
plot(T_domain,alpha_1')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'betas functions'},'FontSize',8,'FontWeight','bold')

subplot(1,3,2)
plot(T_domain,history.Predictor_estimation_FSL')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'The FSL estimate  plotted '},'FontSize',8,'FontWeight','bold')

subplot(1,3,3)
plot(T_domain,history.Predictor_estimation_AFSL')
xlabel('time','FontSize',12,'FontWeight','bold','Color','k')
title({'AFSL estimate plotted'},'FontSize',8,'FontWeight','bold')
