# ------------------------------------------------------------------------------
# -------- Functional Data Classification of the -------------------------------
# -------- Tractography Data using FGRPL         -------------------------------
# ------------------------------------------------------------------------------

## install needed packages if necessary:
# install.packages(c("splines", "grplasso", "refund"))

# FGRPL functions
source("grplFunct.r")

# load the data
load("DTI.RDA")


# -------- Functional Principal Components Analysis ----------------------------

library(refund)

CSTR_aniS <- fpca.sc(as.matrix(CSTR_ani))$Yhat
CSTR_mtrS <- fpca.sc(as.matrix(CSTR_mtr))$Yhat
CSTR_mdS <- fpca.sc(as.matrix(CSTR_md))$Yhat
CSTR_l0S <- fpca.sc(as.matrix(CSTR_l0))$Yhat
CSTR_ltS <- fpca.sc(as.matrix(CSTR_lt))$Yhat
CSTR_t2S <- fpca.sc(as.matrix(CSTR_t2))$Yhat

CSTL_aniS <- fpca.sc(as.matrix(CSTL_ani))$Yhat
CSTL_mtrS <- fpca.sc(as.matrix(CSTL_mtr))$Yhat
CSTL_mdS <- fpca.sc(as.matrix(CSTL_md))$Yhat
CSTL_l0S <- fpca.sc(as.matrix(CSTL_l0))$Yhat
CSTL_ltS <- fpca.sc(as.matrix(CSTL_lt))$Yhat
CSTL_t2S <- fpca.sc(as.matrix(CSTL_t2))$Yhat

CCA_aniS <- fpca.sc(as.matrix(CCA_ani))$Yhat
CCA_mtrS <- fpca.sc(as.matrix(CCA_mtr))$Yhat
CCA_mdS <- fpca.sc(as.matrix(CCA_md))$Yhat
CCA_l0S <- fpca.sc(as.matrix(CCA_l0))$Yhat
CCA_ltS <- fpca.sc(as.matrix(CCA_lt))$Yhat
CCA_t2S <- fpca.sc(as.matrix(CCA_t2))$Yhat

OPRR_aniS <- fpca.sc(as.matrix(OPRR_ani))$Yhat
OPRR_mtrS <- fpca.sc(as.matrix(OPRR_mtr))$Yhat
OPRR_mdS <- fpca.sc(as.matrix(OPRR_md))$Yhat
OPRR_l0S <- fpca.sc(as.matrix(OPRR_l0))$Yhat
OPRR_ltS <- fpca.sc(as.matrix(OPRR_lt))$Yhat
OPRR_t2S <- fpca.sc(as.matrix(OPRR_t2))$Yhat

OPRL_aniS <- fpca.sc(as.matrix(OPRL_ani))$Yhat
OPRL_mtrS <- fpca.sc(as.matrix(OPRL_mtr))$Yhat
OPRL_mdS <- fpca.sc(as.matrix(OPRL_md))$Yhat
OPRL_l0S <- fpca.sc(as.matrix(OPRL_l0))$Yhat
OPRL_ltS <- fpca.sc(as.matrix(OPRL_lt))$Yhat
OPRL_t2S <- fpca.sc(as.matrix(OPRL_t2))$Yhat


XS <- list()
XS[[1]] <- CSTR_aniS
XS[[2]] <- CSTR_mtrS
XS[[3]] <- CSTR_mdS
XS[[4]] <- CSTR_l0S
XS[[5]] <- CSTR_ltS
XS[[6]] <- CSTR_t2S

XS[[7]] <- CSTL_aniS
XS[[8]] <- CSTL_mtrS
XS[[9]] <- CSTL_mdS
XS[[10]] <- CSTL_l0S
XS[[11]] <- CSTL_ltS
XS[[12]] <- CSTL_t2S

XS[[13]] <- CCA_aniS
XS[[14]] <- CCA_mtrS
XS[[15]] <- CCA_mdS
XS[[16]] <- CCA_l0S
XS[[17]] <- CCA_ltS
XS[[18]] <- CCA_t2S

XS[[19]] <- OPRR_aniS
XS[[20]] <- OPRR_mtrS
XS[[21]] <- OPRR_mdS
XS[[22]] <- OPRR_l0S
XS[[23]] <- OPRR_ltS
XS[[24]] <- OPRR_t2S

XS[[25]] <- OPRL_aniS
XS[[26]] <- OPRL_mtrS
XS[[27]] <- OPRL_mdS
XS[[28]] <- OPRL_l0S
XS[[29]] <- OPRL_ltS
XS[[30]] <- OPRL_t2S


names(XS) <- c("CST/right/FA","CST/right/MTR","CST/right/MD",
"CST/right/L0","CST/right/LT","CST/right/T2",
"CST/left/FA","CST/left/MTR","CST/left/MD",
"CST/left/L0","CST/left/LT","CST/left/T2",
"CC/FA","CC/MTR","CC/MD","CC/L0","CC/LT","CC/T2",
"OR/right/FA","OR/right/MTR","OR/right/MD",
"OR/right/L0","OR/right/LT","OR/right/T2",
"OR/left/FA","OR/left/MTR","OR/left/MD",
"OR/left/L0","OR/left/LT","OR/left/T2")


# -------- Regression Analysis -------------------------------------------------

# scaling
p <- length(XS)
XS <- lapply(XS,scale)


# response
y <- outcome_data$case
n <- length(y)
table(y)

# grid
Tps <- list()
for (j in 1:p)
  Tps[[j]] <- 1:ncol(XS[[j]])

# grpl
lambda <- 10^seq(2,-0.5,by=-0.5)
phi <- 10^(5.5)
grpl <- grplFlogit(Y = y, X = XS, Tps = Tps, lambda = lambda, phi = phi,
dfs = 30)

# intercepts
grpl$intercept

# coefficient functions
par(mfrow = c(5,6))
for (j in 1:length(grpl$Coef))
  {
    plot(Tps[[j]], grpl$Coef[[j]][,1], type="l", ylim = range(grpl$Coef[[j]]))
    for (ll in 2:length(lambda))
      lines(Tps[[j]],grpl$Coef[[j]][,ll], col=ll)
      
    title(names(XS)[j])
    #lines(Tps[[j]],grpl$Coef[[j]][,length(lambda)], col=1)
  }
par(mfrow=c(1,1))

# cross-validation (takes some time)
set.seed(1234)
lambda <- 10^seq(2,-0.5,by=-0.05)
phi <- 10^seq(7,1,by=-0.25)
cvError <- cv.grplFlogit(k = 5, Y = y, X = XS, Tps = Tps, lambda = lambda,
phi = phi, dfs = 30)
cvError <- apply(cvError,c(2,3),sum)

plot(log10(lambda),cvError[1,]/n, ylim = range(cvError/n), type="l")
for (pp in 1:length(phi))
  lines(log10(lambda),cvError[pp,]/n, col=grey(1/pp))

cvError2 <- cvError[,length(lambda):1]
cvError2 <- cvError2[length(phi):1,]

xsq <- sort(log10(phi))
ysq <- sort(log10(lambda))
persp(xsq, ysq, cvError2, theta=0, xlab="phi", ylab="lambda", zlab="cv score")


# fitting
grpl <- grplFlogit(Y = y, X = XS, Tps = Tps, lambda = 10^(0.5), phi = 10^(5.5),
dfs = 30)

# coefficient functions
jord <- 1:30
pdf("tract1.pdf", width=10, height=10)
par(mfrow = c(5,6), mar=c(5, 2, 4, 2) + 0.1)
for (j in jord)
  {
    plot(Tps[[j]], grpl$Coef[[j]], type="l", ylim=c(-0.025,0.025),
    bty="n", lwd=1.5,
    xlab="location", ylab="")
    title(names(XS)[j])
  }
par(mfrow=c(1,1))
dev.off()

# fit
etaEst <- rep(grpl$intercept,n)
for (jj in 1:p)
      {
        etaEst <- etaEst + XS[[jj]]%*%grpl$Coef[[jj]]
      }
probsEst <- 1/(1+exp(-etaEst))
boxplot(probsEst ~ y, varwidth=T)
sum((y==1)*log(1/probsEst) + (y==0)*log(1/(1-probsEst)))/n    # 0.295
probsEst0 <- mean(y)
sum((y==1)*log(1/probsEst0) + (y==0)*log(1/(1-probsEst0)))/n  # 0.506

