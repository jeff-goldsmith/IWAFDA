# ------------------------------------------------------------------------------
# -------- Analysis of Chemometrics (Sugar) Data -------------------------------
# ------------------------------------------------------------------------------

# FGRPL functions
source("grplFunct.r")

# load the data
load("Sugar.RDA")

X = lapply(paste0("wave_", c(230, 240, 255, 290, 305, 325, 340)), get)
XD = lapply(paste0("deriv_wave_", c(230, 240, 255, 290, 305, 325, 340)), get)

X <- lapply(X,scale)
XD <- lapply(XD,scale)
XXD <- c(X,XD)
par(mfrow = c(3,5))
for(j in 1:14)
  plot(apply(XXD[[j]],2,var), type="l")
par(mfrow = c(3,5))
for(j in 1:14)
  plot(XXD[[j]][i,], type="l")


# response (ash content *1000)
p <- length(X)
y <- outcome_data$ash
n <- length(y)

# grid points
Tps <- list()
Dps <- list()
for (j in 1:p)
  Tps[[j]] <- seq(from = 275, to = 560, by = .5)
for (j in 1:p)
  Dps[[j]] <- Tps[[j]][-1]


# fit
lambda <- 10^seq(4,1,by=-0.5)
phi <- 10^6
grpl <- grplFlinear(Y = y, X = X, Tps = Tps, lambda = lambda, phi = phi, dfs = 30)

# intercepts
grpl$intercept

# coefficient functions
par(mfrow = c(3,3))
for (j in 1:length(grpl$Coef))
  {
    plot(Tps[[j]], grpl$Coef[[j]][,1], type="l", ylim = range(grpl$Coef[[j]]))
    for (ll in 2:length(lambda))
      lines(Tps[[j]],grpl$Coef[[j]][,ll], col=ll)
    lines(Tps[[j]],grpl$Coef[[j]][,length(lambda)], col=1)      
  }
par(mfrow=c(1,1))

# fit
par(mfrow=c(3,3))
for(ll in 1:length(lambda))
  {
    pred <- rep(grpl$intercept[ll],length(y))
    for (jj in 1:length(X))
      {
        pred <- pred + 0.5*X[[jj]]%*%grpl$Coef[[jj]][,ll]
      }
    plot(y,pred)
    abline(c(0,1))
  }
par(mfrow=c(1,1))

# cross-validation
set.seed(1234)
lambda <- 10^seq(4,0,by=-0.25)
phi <- 10^seq(8,4,by=-2)
cvError <- cv.grplFlinear(k = 5, Y = y, X = X, Tps = Tps, lambda = lambda, 
phi = phi, dfs = 30)

apply(cvError,c(2,3),sum)
plot(log10(lambda),apply(cvError,c(2,3),sum)[1,], 
     #ylim = range(apply(cvError,c(2,3),sum)), 
     ylim = c(0,4000), type="l")
for (pp in 1:length(phi))
  lines(log10(lambda),apply(cvError,c(2,3),sum)[pp,], col=pp)

# fitting
grpl <- grplFlinear(Y = y, X = X, Tps = Tps, lambda = lambda[12], phi = phi[2],
                 dfs = 30)

# coefficient functions
xnames <- paste("Excitation", Sugar$ExAx, "nm")
par(mfrow = c(2,4))
for (j in 1:length(grpl$Coef))
{
  plot(Tps[[j]], grpl$Coef[[j]], type="l", xlab="Emission", 
       ylab="coefficient", ylim=c(-0.05,0.06))
  title(xnames[j])
}
par(mfrow=c(1,1))

# fit
pred <- rep(grpl$intercept,length(y))
for (jj in 1:length(X))
{
  pred <- pred + 0.5*X[[jj]]%*%grpl$Coef[[jj]]
}
plot(y,type="l")
lines(pred,lwd=2,col=2)

plot(y,pred)

mean((y-pred)^2)/var(y)



# adaptive version

# refund fit
library(refund)
smoothFit <- pfr(Y = y, funcs = X, kb = min(30,ceiling(n/p) - 1))
# coefficient functions
par(mfrow = c(3,3))
for (j in 1:length(smoothFit$BetaHat))
  {
    plot(Tps[[j]], smoothFit$BetaHat[[j]], type="l")
  }
par(mfrow=c(1,1))


# weights for adaptive solution
eps <- 10^(-6)
wf1 <- wf2 <- numeric(p)
for (j in 1:p)
  {
    bf <- smoothFit$BetaHat[[j]]
    wf1[j] <- 1/sqrt(sum(bf^2))
    tmax <- length(Tps[[j]])
    wf2[j] <- 1/(sqrt(sum((bf[-c(tmax-1,tmax)] - 2*bf[-c(1,tmax)] + bf[-c(1,2)])^2)) + eps)
  }
wf1 <- p*wf1/sum(wf1)
wf2 <- p*wf2/sum(wf2)

# cross-validation
set.seed(1234)
cvError <- cv.grplFlinear(k = 5, Y = y, X = X, Tps = Tps, lambda = lambda,
phi = phi, dfs = 30, adapt1 = wf1, adapt2 = NULL)
cvError <- apply(cvError,c(2,3),sum)
plot(log10(lambda), cvError[1,], ylim = range(cvError), type="l")
for (pp in 1:length(phi))
  lines(log10(lambda),cvError[pp,], col=pp)

wp <- which.min(apply(cvError,1,min))
wl <- which.min(cvError[wp,])
lines(log10(lambda),cvError[wp,],col=2)
abline(v = log10(lambda[wl]),lty=3)


persp(log10(phi)[order(phi)],log10(lambda)[order(lambda)],
cvError[order(phi),order(lambda)], theta = 50, xlab="phi", ylab="lambda",
zlab="cv error")


# fitting
grplA <- grplFlinear(Y = y, X = X, Tps = Tps, lambda = lambda[12], phi = phi[2],
dfs = 30, adapt1 = wf1, adapt2 = NULL)

# coefficient functions
par(mfrow = c(2,4))
for (j in 1:length(grplA$Coef))
  {
    plot(Tps[[j]], grplA$Coef[[j]], type="l", xlab="Emission (nm)", 
    ylab="coefficient", ylim=c(-0.05,0.06), bty="n", lwd=2)
    lines(Tps[[j]], grpl$Coef[[j]],lty=2,col=2,lwd=2)
    title(xnames[j])
  }
par(mfrow=c(1,1))


j <- 4
plot(Tps[[j]], grplA$Coef[[j]], type="l", xlab="Emission (nm)",
ylab="coefficient", ylim=c(-0.05,0.06), bty="n", lwd=2)
lines(Tps[[j]], grpl$Coef[[j]],lty=2,col=2,lwd=2)
title(xnames[j])


# fit
predA <- rep(grplA$intercept,length(y))
for (jj in 1:length(X))
{
  predA <- predA + 0.5*X[[jj]]%*%grplA$Coef[[jj]]
}

plot(y, type="l", xlab="sample number", ylab="ash (x1000)")
lines(predA,col=3,lwd=2)
lines(pred,col=4,lwd=2,lty=2)


plot(y,predA)
abline(c(0,1))

mean((y-predA)^2)/var(y)
mean((y-pred)^2)/var(y)

mean((y-predA)^2)/mean((y-pred)^2)


mean((pred - predA)^2)/var(y)

plot(pred,predA)


